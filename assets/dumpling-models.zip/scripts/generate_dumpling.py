from pathlib import Path
exec((Path(__file__).parent/'generate_blender.py').read_text().split('def dish(')[0])
OUT=ROOT/'dumpling-models'; OUT.mkdir(exist_ok=True)
for kind in ['soup-dumplings','tonkotsu-ramen','spicy-wontons','pork-bao','scallion-pancake','mango-sticky-rice']:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 white=mat('Porcelain',(.92,.9,.82)); dough=mat('Steamed dough',(.88,.72,.45)); green=mat('Scallions',(.08,.32,.03)); gold=mat('Golden crust',(.65,.31,.06)); red=mat('Chili oil',(.5,.045,.008)); rice=mat('Coconut rice',(.96,.93,.81)); mango=mat('Mango',(.98,.53,.015)); broth=mat('Broth',(.63,.4,.19))
 cyl('27cm demo plate',(0,0,.003),.135,.006,white)
 if kind in ['soup-dumplings','spicy-wontons','pork-bao']:
  if kind=='spicy-wontons':cyl('Chili sauce',(0,0,.007),.105,.002,red)
  for i in range(6):
   a=i*math.tau/6;x=.07*math.cos(a);y=.07*math.sin(a)
   uv('Dumpling',(x,y,.025),(.027,.026,.021),dough if kind!='pork-bao' else rice)
   for j in range(10):
    t=j*math.tau/10
    tube('Pleat',[(x+.024*math.cos(t),y+.024*math.sin(t),.024),(x+.014*math.cos(t+.1),y+.014*math.sin(t+.1),.043),(x+.004*math.cos(t+.2),y+.004*math.sin(t+.2),.047)],.0014,dough)
   uv('Folded top',(x,y,.045),(.007,.007,.004),dough)
 elif kind=='tonkotsu-ramen':
  uv('Bowl',(0,0,.035),(.105,.105,.037),white);cyl('Broth surface',(0,0,.059),.094,.004,broth)
  for j in range(30):
   a=random.random()*math.tau;r=random.uniform(.01,.07)
   tube('Noodle',[(r*math.cos(a+t*.12),r*math.sin(a+t*.12),.064+.002*math.sin(t)) for t in range(25)],.0018,dough)
  for x in [-.035,.035]:
   uv('Egg white',(x,.035,.07),(.021,.028,.008),rice);uv('Egg yolk',(x,.035,.078),(.012,.013,.003),mango)
  for x in [-.03,0,.03]:uv('Pork slice',(x,-.045,.07),(.024,.019,.005),gold)
 elif kind=='scallion-pancake':
  for j in range(3):
   cyl('Layered pancake',(0,0,.01+j*.006),.096-j*.003,.005,gold if j%2==0 else dough)
  for j in range(45):
   a=random.random()*math.tau;r=.086*math.sqrt(random.random());uv('Scallion',(r*math.cos(a),r*math.sin(a),.026),(.005,.002,.001),green)
 else:
  uv('Sticky rice',( -.04,0,.022),(.055,.06,.019),rice)
  for i in range(6):uv('Mango slice',(.035+i*.009,-.023+i*.007,.024),(.012,.05,.009),mango)
  for i in range(75):uv('Rice grain',(-.04+random.uniform(-.035,.035),random.uniform(-.04,.04),.04),(.003,.0013,.001),rice)
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.convert(target='MESH');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 bpy.ops.export_scene.gltf(filepath=str(OUT/(kind+'.glb')),export_format='GLB',use_selection=True,export_yup=True)
 print('EXPORTED',kind)
